import streamlit as st
import hashlib

from resume_reader import read_resume
from skill_extractor import extract_skills
from job_matcher import match_jobs


# Page Settings
st.set_page_config(
    page_title="Resume Screening System",
    page_icon="📄",
    layout="wide"
)


# Sidebar
st.sidebar.title("📌 Navigation")

page = st.sidebar.radio(
    "Go to",
    ["Home", "Resume Screening", "About"]
)


# Session State
if "screening_results" not in st.session_state:
    st.session_state.screening_results = None

if "uploaded_resume" not in st.session_state:
    st.session_state.uploaded_resume = None

if "show_suggestions" not in st.session_state:
    st.session_state.show_suggestions = False


# Home Page
if page == "Home":

    st.title("📄 Resume Screening & Job Recommendation System")

    st.write(
        "Welcome to the Resume Screening and Job Recommendation System."
    )

    st.info(
        "Upload your resume to discover suitable job opportunities."
    )

    st.subheader("✨ Main Features")

    col1, col2, col3, col4 = st.columns(4)

    with col1:
        st.info(
            "📤 Resume Upload\n\nSupports PDF and DOCX files."
        )

    with col2:
        st.success(
            "✅ Skill Extraction\n\nIdentifies skills from resumes."
        )

    with col3:
        st.warning(
            "💼 Job Recommendation\n\nSuggests top 5 matching jobs."
        )

    with col4:
        st.info(
            "🎯 Career Guidance\n\nSuggests more career opportunities."
        )


# Resume Screening Page
elif page == "Resume Screening":

    st.title("📤 Resume Screening")

    resume = st.file_uploader(
        "Upload Your Resume",
        type=["pdf", "docx"]
    )

    if resume is not None:

        # Identify uploaded resume
        file_id = hashlib.sha256(
            resume.getvalue()
        ).hexdigest()

        # Reset results when a new resume is uploaded
        if st.session_state.uploaded_resume != file_id:

            st.session_state.screening_results = None
            st.session_state.show_suggestions = False
            st.session_state.uploaded_resume = file_id

        # Screen Resume Button
        if st.button("🔍 Screen Resume"):

            text = read_resume(resume)

            skills = extract_skills(text)

            recommendations = match_jobs(skills)

            # Save results
            st.session_state.screening_results = {
                "skills": skills,
                "recommendations": recommendations
            }

            st.session_state.show_suggestions = False

    else:

        st.session_state.screening_results = None
        st.session_state.uploaded_resume = None
        st.session_state.show_suggestions = False


    # Display Screening Results
    if st.session_state.screening_results is not None:

        skills = st.session_state.screening_results["skills"]

        recommendations = st.session_state.screening_results[
            "recommendations"
        ]

        # Separate Top 5 and Other Jobs
        top_jobs = recommendations[:5]

        other_jobs = recommendations[5:]

        st.success("Resume Screened Successfully!")

        # Extracted Skills
        st.subheader("✅ Extracted Skills")

        if skills:

            st.write(
                ", ".join(
                    skill.title() for skill in skills
                )
            )

        else:

            st.warning("No skills found.")

        st.divider()

        # Top 5 Job Recommendations
        st.subheader("💼 Top 5 Job Recommendations")

        for job in top_jobs:

            with st.container(border=True):

                st.subheader(job["job_title"])

                st.write(
                    "**Match Percentage:**",
                    str(job["match_percentage"]) + "%"
                )

                st.progress(
                    int(job["match_percentage"])
                )

                st.write("**Matched Skills:**")

                if job["matched_skills"]:

                    st.success(
                        ", ".join(
                            skill.title()
                            for skill in job["matched_skills"]
                        )
                    )

                else:

                    st.warning("No matching skills found.")


        # NEW FEATURE: Career Suggestions
        st.divider()

        st.subheader("🌟 Explore More Career Opportunities")

        st.write(
            "Apart from your Top 5 recommended jobs, "
            "you can also explore other career options "
            "by learning additional skills."
        )

        # Suggest More Jobs Button
        if st.button("🚀 Suggest More Jobs"):

            st.session_state.show_suggestions = True


        # Display Other Job Suggestions
        if st.session_state.show_suggestions:

            st.subheader("💼 You Can Also Explore These Jobs")

            # Select next 5 jobs after Top 5
            suggested_jobs = other_jobs[:5]

            if suggested_jobs:

                for job in suggested_jobs:

                    with st.container(border=True):

                        st.subheader(
                            "💼 " + job["job_title"]
                        )

                        st.write(
                            "📚 **Skills You Should Learn:**"
                        )

                        if job["missing_skills"]:

                            st.warning(
                                ", ".join(
                                    skill.title()
                                    for skill in job["missing_skills"]
                                )
                            )

                            st.info(
                                "💡 If you learn "
                                + ", ".join(
                                    job["missing_skills"]
                                )
                                + ", you can also prepare for a "
                                + job["job_title"]
                                + " role."
                            )

                        else:

                            st.success(
                                "🎉 Your resume already contains "
                                "all the listed skills for this job!"
                            )

            else:

                st.info(
                    "No additional job suggestions available."
                )


# About Page
elif page == "About":

    st.title("ℹ️ About Project")

    st.write(
        "**Project Name:** Resume Screening and "
        "Job Recommendation System"
    )

    st.write("**Programming Language:** Python")

    st.write("**Framework:** Streamlit")

    st.write(
        "**Technology:** Rule-Based Keyword Matching"
    )

    st.subheader("🎯 Project Objective")

    st.write(
        "The objective of this project is to analyze resumes, "
        "identify candidate skills, recommend suitable job roles, "
        "and suggest additional career opportunities based on "
        "skills using simple Python programming techniques."
    )

    st.subheader("⚙️ Working")

    st.write(
        "1. User uploads a resume.\n"
        "2. System extracts text from the resume.\n"
        "3. Skills are identified using keyword matching.\n"
        "4. Skills are compared with 25 predefined job roles.\n"
        "5. Top 5 matching jobs are recommended with percentages.\n"
        "6. User clicks the Suggest More Jobs button.\n"
        "7. System suggests 5 additional job roles.\n"
        "8. Skills to learn are displayed without percentages."
    )

    st.subheader("✨ New Feature")

    st.info(
        "The Career Guidance feature helps users explore "
        "additional job opportunities by suggesting "
        "skills they can learn."
    )