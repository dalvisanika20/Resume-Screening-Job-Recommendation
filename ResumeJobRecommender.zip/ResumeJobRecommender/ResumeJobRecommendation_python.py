from flask import Flask, render_template, request
from markupsafe import escape

from resume_reader import read_resume
from skill_extractor import extract_skills
from job_matcher import match_jobs

app = Flask(__name__)


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/upload", methods=["POST"])
def upload_resume():

    resume = request.files.get("resume")

    if not resume or not resume.filename:
        return "Please select a resume."

    if not resume.filename.lower().endswith((".pdf", ".docx")):
        return "Please upload a PDF or DOCX file.", 400

    # Step 1: Read Resume
    text = read_resume(resume)

    # Step 2: Extract Skills
    skills = extract_skills(text)

    # Step 3: Match Jobs
    recommendations = match_jobs(skills)

    # Step 4: Display Results
    result = "<h2>Resume Screening Result</h2>"

    result += "<h3>Extracted Skills:</h3>"

    if skills:
        for skill in skills:
            result += "<p>✔ " + str(escape(skill.title())) + "</p>"
    else:
        result += "<p>No matching skills found.</p>"

    result += "<h3>Top 5 Job Recommendations:</h3>"

    for job in recommendations:

        result += "<hr>"

        result += "<h4>" + str(escape(job["job_title"])) + "</h4>"

        result += "<p>Match Percentage: " + str(
            job["match_percentage"]
        ) + "%</p>"

        result += "<p>Matched Skills: " + str(
            escape(", ".join(job["matched_skills"]))
        ) + "</p>"

    return result


if __name__ == "__main__":
    app.run(debug=True, use_reloader=False)