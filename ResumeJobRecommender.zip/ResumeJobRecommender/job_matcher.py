from jobs import jobs


def match_jobs(resume_skills):

    recommendations = []

    resume_skills = set(resume_skills)

    for job_title, required_skills in jobs.items():

        # Find matching skills
        matched_skills = resume_skills.intersection(required_skills)

        # Find missing skills
        missing_skills = set(required_skills) - resume_skills

        # Calculate match percentage
        match_percentage = (
            len(matched_skills) / len(required_skills)
        ) * 100

        recommendations.append({

            "job_title": job_title,

            "match_percentage": round(match_percentage, 2),

            "matched_skills": sorted(matched_skills),

            "required_skills": required_skills,

            "missing_skills": sorted(missing_skills)

        })

    # Sort by highest match percentage
    recommendations.sort(
        key=lambda x: x["match_percentage"],
        reverse=True
    )

    # Return all jobs
    # app.py will separate Top 5 and other jobs
    return recommendations