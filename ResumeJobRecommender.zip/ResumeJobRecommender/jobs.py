jobs = {

    "Python Developer": [
        "python", "django", "flask", "sql", "git"
    ],

    "Web Developer": [
        "html", "css", "javascript", "react"
    ],

    "Data Analyst": [
        "python", "sql", "excel", "power bi"
    ],

    "Java Developer": [
        "java", "sql", "spring boot", "git"
    ],

    "Software Developer": [
        "python", "java", "sql", "git"
    ],

    "Frontend Developer": [
        "html", "css", "javascript", "react", "bootstrap"
    ],

    "Backend Developer": [
        "python", "flask", "django", "sql"
    ],

    "PHP Developer": [
        "php", "html", "css", "mysql"
    ],

    "Database Administrator": [
        "sql", "mysql", "mongodb", "database management"
    ],

    "Full Stack Developer": [
        "html", "css", "javascript", "python", "sql", "react"
    ],

    "Cybersecurity Analyst": [
        "python", "linux", "networking", "cybersecurity"
    ],

    "Cloud Engineer": [
        "aws", "azure", "linux", "networking"
    ],

    "DevOps Engineer": [
        "python", "linux", "docker", "git"
    ],

    "Android Developer": [
        "java", "kotlin", "android studio"
    ],

    "Mobile App Developer": [
        "flutter", "dart", "firebase"
    ],

    "UI UX Designer": [
        "figma", "ui design", "ux design"
    ],

    "Software Tester": [
        "python", "selenium", "manual testing"
    ],

    "Machine Learning Engineer": [
        "python", "pandas", "machine learning", "sql"
    ],

    "AI Engineer": [
        "python", "machine learning", "api"
    ],

    "Network Engineer": [
        "networking", "linux", "tcp/ip"
    ],

    "Game Developer": [
        "c#", "unity", "game development"
    ],

    "C++ Developer": [
        "c++", "oop", "dsa"
    ],

    "System Administrator": [
        "linux", "windows server", "networking"
    ],

    "Technical Support Engineer": [
        "troubleshooting", "networking", "windows"
    ],

    "Data Scientist": [
        "python", "pandas", "sql", "statistics"
    ]

}