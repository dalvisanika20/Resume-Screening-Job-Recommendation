import re


def extract_skills(text):

    skills_list = [

        "python", "java", "html", "css",
        "javascript", "sql", "php", "c++",
        "excel", "power bi", "django",
        "flask", "react", "communication",
        "leadership", "data analysis",
        "teamwork", "problem solving",
        "mysql", "mongodb", "git",
        "bootstrap",

        "spring boot", "database management",
        "linux", "networking", "cybersecurity",
        "aws", "azure", "docker",
        "kotlin", "android studio",
        "flutter", "dart", "firebase",
        "figma", "ui design", "ux design",
        "selenium", "manual testing",
        "pandas", "machine learning",
        "api", "tcp/ip", "c#",
        "unity", "game development",
        "oop", "dsa", "windows server",
        "troubleshooting", "windows",
        "statistics"
    ]

    text = text.lower()

    found_skills = []

    for skill in skills_list:

        pattern = r"(?<!\w)" + re.escape(skill) + r"(?!\w)"

        if re.search(pattern, text):
            found_skills.append(skill)

    return found_skills