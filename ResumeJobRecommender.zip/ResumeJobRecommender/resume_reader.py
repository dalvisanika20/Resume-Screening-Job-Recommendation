import fitz
from docx import Document


def read_resume(file):

    filename = file.name.lower()
    text = ""

    if filename.endswith(".pdf"):

        pdf = fitz.open(
            stream=file.read(),
            filetype="pdf"
        )

        for page in pdf:
            text += page.get_text() + "\n"

        pdf.close()

    elif filename.endswith(".docx"):

        document = Document(file)

        for paragraph in document.paragraphs:
            text += paragraph.text + "\n"

    return text